package yerro.com;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class CreateAccountActivity extends AppCompatActivity {

    EditText etUsername, etPassword, etFullName;
    String username, password, fullname;
    int formsuccess, userid;

    DbHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        db = new DbHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etFullName = findViewById(R.id.etFullName);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.save_cancel, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.btnSave:
                username = etUsername.getText().toString();
                password = etPassword.getText().toString();
                fullname = etFullName.getText().toString();
                formsuccess = 3;

                if (username.equals("")) {
                    etUsername.setError("This field is required!");
                    formsuccess--;
                }
                if (password.equals("")) {
                    etPassword.setError("This field is required!");
                    formsuccess--;
                }
                if (fullname.equals("")) {
                    etFullName.setError("This field is required!");
                    formsuccess--;
                }
                if (formsuccess == 3) {
                    HashMap<String, String> map_user = new HashMap();
                    map_user.put(db.tbl_User_Username, username);
                    map_user.put(db.tbl_User_Password, password);
                    map_user.put(db.tbl_User_Fullname, fullname);
                    userid = db.createUser(map_user);
                    if (userid < 1) {
                        Toast.makeText(this, "User Successfully Created", Toast.LENGTH_SHORT).show();
                    } else {
                        etUsername.setError("Username Already Existed!");
                    }
                }


                break;
            case R.id.btnCancel:
                this.finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}