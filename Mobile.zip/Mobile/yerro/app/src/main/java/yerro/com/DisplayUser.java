package yerro.com;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DisplayUser extends AppCompatActivity {

    EditText etUsername, etFullname;
    DbHelper db;
    String username, fullname;
    int formsuccess, userid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_user);
    }
}
