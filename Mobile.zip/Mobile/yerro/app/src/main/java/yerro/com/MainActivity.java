package yerro.com;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etUsername, etPassword;
    Button btnLogin;
    TextView tvCreateAccount;
    String username, password;
    int formsuccess = 0;

    DbHelper db;

    SharedPreferences shared;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        btnLogin = findViewById(R.id.btnLogin);
        tvCreateAccount = findViewById(R.id.tvCreateAccount);

        btnLogin.setOnClickListener(this);
        tvCreateAccount.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnLogin:

                username = etUsername.getText().toString();
                password = etPassword.getText().toString();
                formsuccess = 2;

                if (username.equals("")) {
                    etUsername.setError("This field is required");
                    formsuccess--;
                }

                // validate password
                if (password.equals("")) {
                    etPassword.setError("This field is required");
                    formsuccess--;
                }

                // form successfully validated
                if (formsuccess == 2) {
                    Toast.makeText(getApplicationContext(), "Form successfully validated", Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.tvCreateAccount:
                Intent i = new Intent(this, CreateAccountActivity.class);
                startActivity(i);
                break;
        }
    }

}