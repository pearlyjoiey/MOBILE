package yerro.com;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;


public class DbHelper extends SQLiteOpenHelper {

    public static final String tbl_User = "users",
            tbl_User_ID = "id",
            tbl_User_Username = "username",
            tbl_User_Password = "password",
            tbl_User_Fullname = "fullname";

    SQLiteDatabase dbReadable = getReadableDatabase();
    SQLiteDatabase dbWritable = getWritableDatabase();


    public DbHelper(Context context) {
        super(context, "STIDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql_create_users_table = String.format("CREATE TABLE %s (%s INTEGER PRIMARY KEY AUTOINCREMENT, %s TEXT, %s TEXT, %s TEXT)",
                tbl_User, tbl_User_ID, tbl_User_Username, tbl_User_Password, tbl_User_Fullname);
        db.execSQL(sql_create_users_table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public int createUser(HashMap<String, String> map_user) {
        int userid = 0;
        String sql_check_username = String.format("SELECT * FROM %s WHERE %s = '%s'",
                tbl_User, tbl_User_Username, map_user.get(tbl_User_Username));
        Cursor cur = dbReadable.rawQuery(sql_check_username, null);
        if(cur.moveToNext()) {
            userid = cur.getInt(cur.getColumnIndex(tbl_User_ID));
        }
        else {
            // Insertion of data to database
            ContentValues val = new ContentValues();
            val.put(tbl_User_Username, map_user.get(tbl_User_Username));
            val.put(tbl_User_Password, map_user.get(tbl_User_Password));
            val.put(tbl_User_Fullname, map_user.get(tbl_User_Fullname));
            dbWritable.insert(tbl_User, null, val);
        }
        return userid;
    }

    public int checkUser(HashMap<String, String> map_user) {

        String sql = String.format("SELECT * FROM %s WHERE %s = '%s' AND %s = '%s'",
                tbl_User, tbl_User_Username, map_user.get(tbl_User_Username), tbl_User_Password, map_user.get(tbl_User_Password));
        Cursor cur = dbReadable.rawQuery(sql, null);

        int userId = 0;

        if(cur.moveToNext()){
            userId= cur.getInt(cur.getColumnIndex(tbl_User_ID));
        }
        return userId;
    }

    public ArrayList<HashMap<String, String>> getAllUsers() {
        ArrayList<HashMap<String, String>> all_users = new ArrayList();
        String sql_get_users = String.format("SELECT * FROM %s ORDER BY %s ASC",tbl_User, tbl_User_Fullname);

        Cursor cur = dbReadable.rawQuery(sql_get_users, null);
        while(cur.moveToNext()){
            HashMap<String, String> map_user = new HashMap();
            map_user.put(tbl_User_ID, cur.getString(cur.getColumnIndex(tbl_User_ID)));
            map_user.put(tbl_User_Fullname, cur.getString(cur.getColumnIndex(tbl_User_Fullname)));
            map_user.put(tbl_User_Username, cur.getString(cur.getColumnIndex(tbl_User_Username)));
            all_users.add(map_user);
        }
        cur.close();
        return all_users;
    }

    public void deleteUser(int userid) {
        dbWritable.delete(tbl_User, tbl_User_ID + "=" +userid, null);
    }

    public ArrayList<HashMap<String, String>> getSelectUser(int userid) {

        String sql = "SELECT * FROM " + tbl_User + " WHERE " + tbl_User_ID + " = " +userid;
        Cursor cur = dbReadable.rawQuery(sql, null);

        ArrayList<HashMap<String, String>> select_user = new ArrayList();

        while (cur.moveToNext()){
            HashMap<String , String> map_user = new HashMap();
            map_user.put(tbl_User_Password, cur.getString(cur.getColumnIndex(tbl_User_Password)));
            map_user.put(tbl_User_Fullname, cur.getString(cur.getColumnIndex(tbl_User_Fullname)));
            map_user.put(tbl_User_Username, cur.getString(cur.getColumnIndex(tbl_User_Username)));
            select_user.add(map_user);

        }
        cur.close();

        return select_user;
    }



    public void updateUser(HashMap<String, String> map_user) {
        ContentValues val = new ContentValues();
        val.put(tbl_User_Username, map_user.get(tbl_User_Username));
        val.put(tbl_User_Password,map_user.get(tbl_User_Password));
        val.put(tbl_User_Fullname, map_user.get(tbl_User_Fullname));

        dbWritable.update(tbl_User, val, tbl_User_ID + " = " + map_user.get(tbl_User_ID), null);
    }
}
